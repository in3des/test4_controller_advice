package com.myform.test.service;

import com.myform.test.dto.SectorDto;
import com.myform.test.model.Sector;

import java.util.List;

public interface SectorService {
    List<Sector> getAll();
}
